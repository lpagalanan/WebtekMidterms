<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'webtek');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '8}Oug4h,ydti4-|Cy~L=.t5)HJm`v+Ks-/0OJkhMU&By+V;YsU!!IHhT?gj.ri p');
define('SECURE_AUTH_KEY',  '[}+Sf@2,[()FC>Q1wiZlZn7bgX>gS:ZMm]^,;VQ#3Qs.+GW0_o~5,=mS*h~h[*f`');
define('LOGGED_IN_KEY',    '$.3|)%?MIIRqOvo|hI^qf/)<4j5+K6nnX(}a_Op]s)H<XMj9CRS%QHWg5,m]MG]I');
define('NONCE_KEY',        'OA2ud@yXV-yR[GVg|Y&a*)Q`csp&/=_6up9u_0EOsYVsKKSlc_~:K$x4kCoq:H-0');
define('AUTH_SALT',        'V1,_],7Y6@~NA5`=cL7yAfWDHr2e&b{JVwN5ur2R/o@PVFl~Z{tGAK}gW1;+z@>j');
define('SECURE_AUTH_SALT', 'B,$B)B8Os/0DC/ngBm~0wPITh}]_cc>XQ_n6af/8n.1}Y@U#Qbp2oa%0oSqxKpe0');
define('LOGGED_IN_SALT',   ')`s(U0M.LI1q-^dSk:oE|h2vg)Q[]IR,d!.$Vyn2%#qx[CK:,Cuqu@]fmO3)kT7Z');
define('NONCE_SALT',       'F][/#6m+uI/E5K8[/7X0(tPx_tS02]e9oHfp>6&h^1/0C4ZskP[jot8=wQ3EjKkT');
define( 'WP_MAX_MEMORY_LIMIT' , '512M' );
/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
