<p><?php printf(__('Ultimate Member is not yet available in your language: <strong>%1$s</strong>.','ultimate-member'), $locale); ?></p>

<p><?php _e('If you want to contribute this translation to the plugin, please add it on our <a href="https://ultimatemember.com/forums/">community forum</a>.','ultimate-member'); ?></p>